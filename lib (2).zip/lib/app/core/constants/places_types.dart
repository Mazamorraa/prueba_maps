final List<Map<String, String>> placeTypes = [
  {'name': 'Escoja lugar a buscar', 'value': ''}, // placeholder
  {'name': 'Restaurantes', 'value': 'restaurant'},
  {'name': 'Hospitales', 'value': 'hospital'},
  {'name': 'Parques', 'value': 'park'},
  {'name': 'Gimnasios', 'value': 'gym'},
  {'name': 'Tiendas', 'value': 'store'},
  {'name': 'Cafeterías', 'value': 'cafe'},
  {'name': 'Farmacias', 'value': 'pharmacy'},
  {'name': 'Bancos', 'value': 'bank'},
  {'name': 'Hoteles', 'value': 'lodging'},
  {'name': 'Gasolineras', 'value': 'gas_station'},
];
